var searchData=
[
  ['decimal_2ehpp_789',['decimal.hpp',['../decimal_8hpp.html',1,'']]]
];
