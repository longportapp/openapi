var searchData=
[
  ['decimal_2ehpp_783',['decimal.hpp',['../decimal_8hpp.html',1,'']]]
];
