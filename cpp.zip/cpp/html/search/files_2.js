var searchData=
[
  ['decimal_2ehpp_782',['decimal.hpp',['../decimal_8hpp.html',1,'']]]
];
