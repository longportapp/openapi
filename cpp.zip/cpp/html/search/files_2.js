var searchData=
[
  ['decimal_2ehpp_784',['decimal.hpp',['../decimal_8hpp.html',1,'']]]
];
