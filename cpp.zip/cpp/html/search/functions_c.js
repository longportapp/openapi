var searchData=
[
  ['norm_5fpdf_853',['norm_pdf',['../classlongport_1_1_decimal.html#a615361713c4c0dace7646b5a857966b6',1,'longport::Decimal']]],
  ['normalize_854',['normalize',['../classlongport_1_1_decimal.html#acacc87e656f1f30803753113c92a9d1f',1,'longport::Decimal']]]
];
