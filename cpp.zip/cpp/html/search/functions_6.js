var searchData=
[
  ['get_5fasync_5fcallback_827',['get_async_callback',['../namespacelongport_1_1callback.html#a332e16fe8c5d6af8ab3ca85c6c9a23e0',1,'longport::callback']]],
  ['get_5fpush_5fcallback_828',['get_push_callback',['../namespacelongport_1_1callback.html#ad0206624e59795e28793968c1e15f91b',1,'longport::callback']]]
];
