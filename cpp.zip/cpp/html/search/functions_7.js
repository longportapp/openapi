var searchData=
[
  ['has_5foption_829',['has_option',['../structlongport_1_1quote_1_1_derivative_type.html#ae7f8ee2d7bcdb85a6eb1e49cb991bbbe',1,'longport::quote::DerivativeType']]],
  ['has_5fwarrant_830',['has_warrant',['../structlongport_1_1quote_1_1_derivative_type.html#a884a8c597aedad00eb88696f106e992d',1,'longport::quote::DerivativeType']]],
  ['history_5fcandlesticks_5fby_5fdate_831',['history_candlesticks_by_date',['../classlongport_1_1quote_1_1_quote_context.html#a3a190cad466539c10dd551e25f524bab',1,'longport::quote::QuoteContext']]],
  ['history_5fcandlesticks_5fby_5foffset_832',['history_candlesticks_by_offset',['../classlongport_1_1quote_1_1_quote_context.html#a6bb450758399575bb550a146bdfc1467',1,'longport::quote::QuoteContext']]],
  ['history_5fexecutions_833',['history_executions',['../classlongport_1_1trade_1_1_trade_context.html#a0b828929e88d1c927dd6e1e395a9a99a',1,'longport::trade::TradeContext']]],
  ['history_5fmarket_5ftemperature_834',['history_market_temperature',['../classlongport_1_1quote_1_1_quote_context.html#a4152e205396ea63db0395cfd4550c70e',1,'longport::quote::QuoteContext']]],
  ['history_5forders_835',['history_orders',['../classlongport_1_1trade_1_1_trade_context.html#a8888f9c11de329d9db46090e594f9091',1,'longport::trade::TradeContext']]],
  ['httpclient_836',['HttpClient',['../classlongport_1_1_http_client.html#aa85a3f95f001be8dd051a8cbf087811c',1,'longport::HttpClient::HttpClient()'],['../classlongport_1_1_http_client.html#a91ee4478c7436c98303c761d244511c5',1,'longport::HttpClient::HttpClient(HttpClient &amp;)=delete'],['../classlongport_1_1_http_client.html#a642b8a6dd8f8b4ed5ac65dd3c91fc14d',1,'longport::HttpClient::HttpClient(const std::string &amp;http_url, const std::string &amp;app_key, const std::string &amp;app_secret, const std::string &amp;access_token)']]],
  ['httpresult_837',['HttpResult',['../structlongport_1_1_http_result.html#a28737d70dc757a5bfd489677dfc150d5',1,'longport::HttpResult']]]
];
