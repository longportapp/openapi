var searchData=
[
  ['errorkind_1190',['ErrorKind',['../namespacelongport.html#af5bcd3a8c3c5f5e8487253e271398b48',1,'longport']]]
];
