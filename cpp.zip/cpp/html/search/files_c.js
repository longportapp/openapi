var searchData=
[
  ['trade_5fcontext_2ehpp_2563',['trade_context.hpp',['../trade__context_8hpp.html',1,'']]],
  ['types_2ehpp_2564',['types.hpp',['../types_8hpp.html',1,'']]]
];
