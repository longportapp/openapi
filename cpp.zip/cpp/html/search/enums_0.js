var searchData=
[
  ['adjusttype_1176',['AdjustType',['../namespacelongport_1_1quote.html#a866ffe475bc2cef271e858a5bdf16d6a',1,'longport::quote']]]
];
