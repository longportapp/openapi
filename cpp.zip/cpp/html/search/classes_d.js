var searchData=
[
  ['realtimequote_749',['RealtimeQuote',['../structlongport_1_1quote_1_1_realtime_quote.html',1,'longport::quote']]],
  ['replaceorderoptions_750',['ReplaceOrderOptions',['../structlongport_1_1trade_1_1_replace_order_options.html',1,'longport::trade']]]
];
