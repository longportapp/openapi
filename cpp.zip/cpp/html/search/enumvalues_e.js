var searchData=
[
  ['quarter_1331',['Quarter',['../namespacelongport_1_1quote.html#a60167d694ea9a5fec686d08fa21dae17ab25cde1e74f3d27f678c2e309e06102e',1,'longport::quote']]]
];
