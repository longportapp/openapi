var searchData=
[
  ['unsubscribe_935',['unsubscribe',['../classlongport_1_1quote_1_1_quote_context.html#ab52a7ca741595003213ed7a2f1f88491',1,'longport::quote::QuoteContext::unsubscribe()'],['../classlongport_1_1trade_1_1_trade_context.html#a2abb31b9da78bff20be2c4711ea14611',1,'longport::trade::TradeContext::unsubscribe()']]],
  ['unsubscribe_5fcandlesticks_936',['unsubscribe_candlesticks',['../classlongport_1_1quote_1_1_quote_context.html#a1959b01fab55b0ed5efd59240a23678b',1,'longport::quote::QuoteContext']]],
  ['update_5fwatchlist_5fgroup_937',['update_watchlist_group',['../classlongport_1_1quote_1_1_quote_context.html#aa32421ee6a372a48b94f79e87ee57fb1',1,'longport::quote::QuoteContext']]]
];
