var searchData=
[
  ['ln_837',['ln',['../classlongport_1_1_decimal.html#a59e7469f7dfe70af973ebe9f95bfa95d',1,'longport::Decimal']]],
  ['log10_838',['log10',['../classlongport_1_1_decimal.html#a76c14efd34e5a2ae85a92e6a277b7bc1',1,'longport::Decimal']]]
];
