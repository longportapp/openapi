var searchData=
[
  ['kind_846',['kind',['../classlongport_1_1_status.html#a0a0c4640563a1329104d1eeeb7c3863f',1,'longport::Status']]]
];
