var searchData=
[
  ['year_1391',['Year',['../namespacelongport_1_1quote.html#a60167d694ea9a5fec686d08fa21dae17a537c66b24ef5c83b7382cdc3f34885f2',1,'longport::quote']]],
  ['ytdchangerate_1392',['YtdChangeRate',['../namespacelongport_1_1quote.html#a1057d28d1b3ec4b2f7847b2f53a4fbbea6f3601e08bc5e8390f2abd4db47ae922',1,'longport::quote']]]
];
