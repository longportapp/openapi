var searchData=
[
  ['gamma_1019',['gamma',['../structlongport_1_1quote_1_1_security_calc_index.html#a98b82fe5c31842d53a94d15a4850af28',1,'longport::quote::SecurityCalcIndex']]],
  ['granularity_1020',['granularity',['../structlongport_1_1quote_1_1_history_market_temperature_response.html#ab462a12961a903eaf0259171cd40469d',1,'longport::quote::HistoryMarketTemperatureResponse']]]
];
