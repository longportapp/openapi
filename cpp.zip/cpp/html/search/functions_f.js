var searchData=
[
  ['realtime_5fbrokers_887',['realtime_brokers',['../classlongport_1_1quote_1_1_quote_context.html#ac32c5174f0460c71a3842d19e0f33728',1,'longport::quote::QuoteContext']]],
  ['realtime_5fcandlesticks_888',['realtime_candlesticks',['../classlongport_1_1quote_1_1_quote_context.html#a0cabb54dc93a29c3acd5b5219c28a2b2',1,'longport::quote::QuoteContext']]],
  ['realtime_5fdepth_889',['realtime_depth',['../classlongport_1_1quote_1_1_quote_context.html#a61ff545ee272ee6ef49a46ccec25355c',1,'longport::quote::QuoteContext']]],
  ['realtime_5fquote_890',['realtime_quote',['../classlongport_1_1quote_1_1_quote_context.html#a59a1b824687ca339e0024aa3e95e8337',1,'longport::quote::QuoteContext']]],
  ['realtime_5ftrades_891',['realtime_trades',['../classlongport_1_1quote_1_1_quote_context.html#ae049f3a2b3702f9581fc1b661204ba9e',1,'longport::quote::QuoteContext']]],
  ['ref_5fcount_892',['ref_count',['../classlongport_1_1quote_1_1_quote_context.html#ad803691ea8a55876772217a227179dc0',1,'longport::quote::QuoteContext::ref_count()'],['../classlongport_1_1trade_1_1_trade_context.html#a4eae5c9833f4715e271b56bb90456698',1,'longport::trade::TradeContext::ref_count()']]],
  ['refresh_5faccess_5ftoken_893',['refresh_access_token',['../classlongport_1_1_config.html#aca19964c285565a678bfc2cb7d84350d',1,'longport::Config']]],
  ['replace_5forder_894',['replace_order',['../classlongport_1_1trade_1_1_trade_context.html#afa3fa829926992ed757c8c7db2436a5d',1,'longport::trade::TradeContext']]],
  ['request_895',['request',['../classlongport_1_1_http_client.html#af1d157da5f0c1bf6f65743c145b7e6d1',1,'longport::HttpClient']]],
  ['round_896',['round',['../classlongport_1_1_decimal.html#a4b66efd41d4f019543f30b80d7839122',1,'longport::Decimal::round()'],['../classlongport_1_1_decimal.html#a8448bd119d690b311327408c655da969',1,'longport::Decimal::round(uint32_t dp)']]]
];
