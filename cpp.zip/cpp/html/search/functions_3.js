var searchData=
[
  ['decimal_817',['Decimal',['../classlongport_1_1_decimal.html#a08a21c8b93edae6207ab71a6abb80090',1,'longport::Decimal::Decimal(const lb_decimal_t *other)'],['../classlongport_1_1_decimal.html#a26ef56b8f766a9a404efe858d8cdbf6b',1,'longport::Decimal::Decimal(const Decimal &amp;other)'],['../classlongport_1_1_decimal.html#ad44d3b54ceba1837f02a8cac4a6e7dcb',1,'longport::Decimal::Decimal(const char *str)'],['../classlongport_1_1_decimal.html#a7dae8e7efd35487f4d51c42fea92f97c',1,'longport::Decimal::Decimal(const std::string &amp;str)'],['../classlongport_1_1_decimal.html#a57a3d973dd2e5b4b1fae25ef2ddce5e6',1,'longport::Decimal::Decimal(double other)'],['../classlongport_1_1_decimal.html#a89219eb576340a32035d4b88619d466e',1,'longport::Decimal::Decimal(double other, uint32_t dp)']]],
  ['delete_5fwatchlist_5fgroup_818',['delete_watchlist_group',['../classlongport_1_1quote_1_1_quote_context.html#a1b8e5908b341a168a5e277f4a416f000',1,'longport::quote::QuoteContext']]],
  ['depth_819',['depth',['../classlongport_1_1quote_1_1_quote_context.html#a18378bc8631dcbdc0c430d087b64dba8',1,'longport::quote::QuoteContext']]],
  ['depth_820',['DEPTH',['../classlongport_1_1quote_1_1_sub_flags.html#afaf033776f9882c49a666aefe718f7ff',1,'longport::quote::SubFlags']]]
];
