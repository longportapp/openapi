var searchData=
[
  ['updatewatchlistgroup_777',['UpdateWatchlistGroup',['../structlongport_1_1quote_1_1_update_watchlist_group.html',1,'longport::quote']]]
];
