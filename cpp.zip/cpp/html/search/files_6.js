var searchData=
[
  ['quote_5fcontext_2ehpp_795',['quote_context.hpp',['../quote__context_8hpp.html',1,'']]]
];
