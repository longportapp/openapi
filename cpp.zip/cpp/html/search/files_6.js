var searchData=
[
  ['quote_5fcontext_2ehpp_786',['quote_context.hpp',['../quote__context_8hpp.html',1,'']]]
];
