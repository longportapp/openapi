var searchData=
[
  ['erf_819',['erf',['../classlongport_1_1_decimal.html#a133e57878dcd1a5b498b35e11d48b933',1,'longport::Decimal']]],
  ['estimate_5fmax_5fpurchase_5fquantity_820',['estimate_max_purchase_quantity',['../classlongport_1_1trade_1_1_trade_context.html#adb04970c8e8830b3a1d7ccb83ba04544',1,'longport::trade::TradeContext']]],
  ['exp_821',['exp',['../classlongport_1_1_decimal.html#ad386fa57befe35b32519191753e3df82',1,'longport::Decimal']]],
  ['exp_5fwith_5ftolerance_822',['exp_with_tolerance',['../classlongport_1_1_decimal.html#ad595ae03ff7361ff15a6e7757117fc0b',1,'longport::Decimal']]]
];
