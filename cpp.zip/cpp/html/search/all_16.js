var searchData=
[
  ['year_689',['year',['../structlongport_1_1_date.html#a318a24d6fec46d77dc4cd229ba9f8558',1,'longport::Date']]],
  ['year_690',['Year',['../namespacelongport_1_1quote.html#a60167d694ea9a5fec686d08fa21dae17a537c66b24ef5c83b7382cdc3f34885f2',1,'longport::quote']]],
  ['ytd_5fchange_5frate_691',['ytd_change_rate',['../structlongport_1_1quote_1_1_security_calc_index.html#a7b15a1033312130036ee43c4efe76e42',1,'longport::quote::SecurityCalcIndex']]],
  ['ytdchangerate_692',['YtdChangeRate',['../namespacelongport_1_1quote.html#a1057d28d1b3ec4b2f7847b2f53a4fbbea6f3601e08bc5e8390f2abd4db47ae922',1,'longport::quote']]]
];
