var searchData=
[
  ['granularity_1188',['Granularity',['../namespacelongport_1_1quote.html#a3c44f69c0146a4f836f4f75fe8c90d5c',1,'longport::quote']]]
];
