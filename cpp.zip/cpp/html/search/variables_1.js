var searchData=
[
  ['balance_959',['balance',['../structlongport_1_1trade_1_1_cash_flow.html#ab744beab2de5df57684815ffe512dcdd',1,'longport::trade::CashFlow']]],
  ['balance_5fpoint_960',['balance_point',['../structlongport_1_1quote_1_1_security_calc_index.html#a0efc3ba41b4b38d9391a92279b2923b0',1,'longport::quote::SecurityCalcIndex::balance_point()'],['../structlongport_1_1quote_1_1_warrant_info.html#ab523c55ea6fed2d3c239018e2a53df54',1,'longport::quote::WarrantInfo::balance_point()']]],
  ['begin_5ftime_961',['begin_time',['../structlongport_1_1quote_1_1_trading_session_info.html#a52aa27acb1704a33d9a42180ef2c8fea',1,'longport::quote::TradingSessionInfo']]],
  ['bid_5fbrokers_962',['bid_brokers',['../structlongport_1_1quote_1_1_push_brokers.html#a755653c5d62624c4c750347dc9636fc3',1,'longport::quote::PushBrokers::bid_brokers()'],['../structlongport_1_1quote_1_1_security_brokers.html#ae68a23500648af62ea5da8f625a06fbb',1,'longport::quote::SecurityBrokers::bid_brokers()']]],
  ['bids_963',['bids',['../structlongport_1_1quote_1_1_push_depth.html#a0cbaefde616664b75b65fcaf213edb79',1,'longport::quote::PushDepth::bids()'],['../structlongport_1_1quote_1_1_security_depth.html#ae47230b05d71e024c8dea3d4c6bf282d',1,'longport::quote::SecurityDepth::bids()']]],
  ['board_964',['board',['../structlongport_1_1quote_1_1_security_static_info.html#a9ca64bbfbef8d2c547d05ae95a503eb0',1,'longport::quote::SecurityStaticInfo']]],
  ['bps_965',['bps',['../structlongport_1_1quote_1_1_security_static_info.html#abeeb130124836c0aedaf4536316f713c',1,'longport::quote::SecurityStaticInfo']]],
  ['broker_5fids_966',['broker_ids',['../structlongport_1_1quote_1_1_brokers.html#ace886a7926938f4a861f572d9b9605d2',1,'longport::quote::Brokers::broker_ids()'],['../structlongport_1_1quote_1_1_participant_info.html#acfa72e3e37c987b86d64c988f627a87d',1,'longport::quote::ParticipantInfo::broker_ids()']]],
  ['business_5ftime_967',['business_time',['../structlongport_1_1trade_1_1_cash_flow.html#a73b97626344db49ef01db17b0ecfee71',1,'longport::trade::CashFlow']]],
  ['business_5ftype_968',['business_type',['../structlongport_1_1trade_1_1_cash_flow.html#aeaf0ef3495f851d6f8825f49c2a515e9',1,'longport::trade::CashFlow::business_type()'],['../structlongport_1_1trade_1_1_get_cash_flow_options.html#ab7d78c9848b71593fbce3d3ff02432a0',1,'longport::trade::GetCashFlowOptions::business_type()']]],
  ['buy_5fpower_969',['buy_power',['../structlongport_1_1trade_1_1_account_balance.html#a281e0f4c4585fbe70e5eb40873e48fbf',1,'longport::trade::AccountBalance']]]
];
