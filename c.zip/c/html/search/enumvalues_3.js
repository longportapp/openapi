var searchData=
[
  ['deductionstatusdone_1450',['DeductionStatusDone',['../longport_8h.html#a20d1ba69477473c4756e801c567ee32da6dd36da579baa3498f51ee460bc3b2f4',1,'longport.h']]],
  ['deductionstatusnodata_1451',['DeductionStatusNoData',['../longport_8h.html#a20d1ba69477473c4756e801c567ee32da3cef047c9387f7ad37bbc722ea5e987c',1,'longport.h']]],
  ['deductionstatusnone_1452',['DeductionStatusNone',['../longport_8h.html#a20d1ba69477473c4756e801c567ee32da9650abc2e2f9faa5440cf264259fc141',1,'longport.h']]],
  ['deductionstatuspending_1453',['DeductionStatusPending',['../longport_8h.html#a20d1ba69477473c4756e801c567ee32daa449fc6ac9e0568a0ac40e9089629aae',1,'longport.h']]],
  ['deductionstatusunknown_1454',['DeductionStatusUnknown',['../longport_8h.html#a20d1ba69477473c4756e801c567ee32daf943cd05962a87e36ceed5909fff620a',1,'longport.h']]]
];
