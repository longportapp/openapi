var searchData=
[
  ['balance_979',['balance',['../structlb__cash__flow__t.html#a3c5a6b3ec5703721e147cb349e30108a',1,'lb_cash_flow_t']]],
  ['balance_5fpoint_980',['balance_point',['../structlb__security__calc__index__t.html#a25f39636eed7efb3890c0004619c4560',1,'lb_security_calc_index_t::balance_point()'],['../structlb__warrant__info__t.html#a25f39636eed7efb3890c0004619c4560',1,'lb_warrant_info_t::balance_point()']]],
  ['begin_5ftime_981',['begin_time',['../structlb__trading__session__info__t.html#abf5f33aca0e250576b9ab6bed2431bce',1,'lb_trading_session_info_t']]],
  ['bid_5fbrokers_982',['bid_brokers',['../structlb__push__brokers__t.html#a367a03e1eb5d039fcbd7b6dce27f95d4',1,'lb_push_brokers_t::bid_brokers()'],['../structlb__security__brokers__t.html#a367a03e1eb5d039fcbd7b6dce27f95d4',1,'lb_security_brokers_t::bid_brokers()']]],
  ['bids_983',['bids',['../structlb__push__depth__t.html#a6beb182c0d0f92c8d76bcf7f932e5982',1,'lb_push_depth_t::bids()'],['../structlb__security__depth__t.html#a6beb182c0d0f92c8d76bcf7f932e5982',1,'lb_security_depth_t::bids()']]],
  ['board_984',['board',['../structlb__security__static__info__t.html#a8a86312fb8edb12800787fdd87346239',1,'lb_security_static_info_t']]],
  ['bps_985',['bps',['../structlb__security__static__info__t.html#a6895b3cd03829baa75b769a966c8b224',1,'lb_security_static_info_t']]],
  ['broker_5fids_986',['broker_ids',['../structlb__brokers__t.html#aa60628722a72867302c59acd932e7bd3',1,'lb_brokers_t::broker_ids()'],['../structlb__participant__info__t.html#aa60628722a72867302c59acd932e7bd3',1,'lb_participant_info_t::broker_ids()']]],
  ['business_5ftime_987',['business_time',['../structlb__cash__flow__t.html#a4cf70ee86ab76a3d8e62e7379f2c320d',1,'lb_cash_flow_t']]],
  ['business_5ftype_988',['business_type',['../structlb__get__cash__flow__options__t.html#a6b5eac076160bb5dd5254f08b8386f40',1,'lb_get_cash_flow_options_t::business_type()'],['../structlb__cash__flow__t.html#ac6a985190c6feafb33e8f5cd4d9a84c1',1,'lb_cash_flow_t::business_type()']]],
  ['buy_5fpower_989',['buy_power',['../structlb__account__balance__t.html#a0d5b99ec2d2d1d7c4c9cd6554808ae3b',1,'lb_account_balance_t']]]
];
