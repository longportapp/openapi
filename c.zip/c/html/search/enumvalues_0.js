var searchData=
[
  ['adjusttypeforward_1387',['AdjustTypeForward',['../longport_8h.html#ac7dfa4da1bb548d6575c619f3f22515fa56ffbdbf49c35dc37c367183b427797e',1,'longport.h']]],
  ['adjusttypenoadjust_1388',['AdjustTypeNoAdjust',['../longport_8h.html#ac7dfa4da1bb548d6575c619f3f22515fa2431e5109013a7697b3e8fb30950d916',1,'longport.h']]]
];
