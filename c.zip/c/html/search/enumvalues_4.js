var searchData=
[
  ['granularitydaily_1439',['GranularityDaily',['../longport_8h.html#ac642c0c57b044e0b95b30cc4dc909120a586d968ee933d5af0e0999ebb6ff0231',1,'longport.h']]],
  ['granularitymonthly_1440',['GranularityMonthly',['../longport_8h.html#ac642c0c57b044e0b95b30cc4dc909120ab4edd426d7039ff7e82151efd2e724f3',1,'longport.h']]],
  ['granularityunknown_1441',['GranularityUnknown',['../longport_8h.html#ac642c0c57b044e0b95b30cc4dc909120ae3d262a0ce38dbaa81a452333122eca5',1,'longport.h']]],
  ['granularityweekly_1442',['GranularityWeekly',['../longport_8h.html#ac642c0c57b044e0b95b30cc4dc909120a8d2c31d415722e66f25fbbd19803b520',1,'longport.h']]]
];
