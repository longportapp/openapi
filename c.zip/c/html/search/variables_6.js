var searchData=
[
  ['gamma_1052',['gamma',['../structlb__security__calc__index__t.html#a1c2926f413a50fbffef7aadd4cd33d53',1,'lb_security_calc_index_t']]],
  ['granularity_1053',['granularity',['../structlb__history__market__temperature__response__t.html#a971132c38a33c335725eaf183683123b',1,'lb_history_market_temperature_response_t']]]
];
