var searchData=
[
  ['language_5fen_1443',['Language_EN',['../longport_8h.html#ad746ba63a793b4e10cc564f6ae7aad1fae9c695c416f014fbd506e8bc75412f59',1,'longport.h']]],
  ['language_5fzh_5fcn_1444',['Language_ZH_CN',['../longport_8h.html#ad746ba63a793b4e10cc564f6ae7aad1faa474147a7830e4ac380329decce70e8a',1,'longport.h']]],
  ['language_5fzh_5fhk_1445',['Language_ZH_HK',['../longport_8h.html#ad746ba63a793b4e10cc564f6ae7aad1fa5d29f72c612e972f4575de179a4a6858',1,'longport.h']]]
];
