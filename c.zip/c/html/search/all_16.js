var searchData=
[
  ['year_765',['year',['../structlb__date__t.html#a667e2fa6fd51e046a6475b461a53dc0a',1,'lb_date_t']]],
  ['ytd_5fchange_5frate_766',['ytd_change_rate',['../structlb__security__calc__index__t.html#a3d30cebe2b0c9deff89363cb0f88dd82',1,'lb_security_calc_index_t']]]
];
